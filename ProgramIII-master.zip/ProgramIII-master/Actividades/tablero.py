class Tablero:

    def set_tamano(self,tamano_i,tamano_j):
        self._tamano_i = tamano_i
        self._tamano_j = tamano_j

    def get_tamano(self):
        return self._tamano